#!/bin/bash

set -e

# === Config ===
PROJECT_DIR="openvpn-tailscale"
TAILSCALE_AUTH_KEY="tskey-xxxxxxxxxxxxxxxx"  # <- Bạn thay bằng key thật của bạn

# === Tạo thư mục ===
mkdir -p $PROJECT_DIR/openvpn-data
mkdir -p $PROJECT_DIR/tailscale-data

# === Tạo docker-compose.yml ===
cat > $PROJECT_DIR/docker-compose.yml <<'EOF'
version: '3.8'

services:
  tailscale:
    image: tailscale/tailscale
    container_name: tailscale
    cap_add:
      - NET_ADMIN
      - SYS_MODULE
    devices:
      - /dev/net/tun
    volumes:
      - ./tailscale-data:/var/lib/tailscale
      - /dev/net/tun:/dev/net/tun
    command: tailscaled
    networks:
      tailscale-net:
        ipv4_address: 100.64.0.2

  openvpn:
    image: kylemanna/openvpn
    container_name: openvpn
    depends_on:
      - tailscale
    cap_add:
      - NET_ADMIN
    sysctls:
      - net.ipv4.ip_forward=1
    volumes:
      - ./openvpn-data:/etc/openvpn
    networks:
      tailscale-net:
        ipv4_address: 100.64.0.3

  openvpn-admin:
    image: flant/openvpn-admin
    container_name: openvpn-admin
    ports:
      - "8080:8080"
    environment:
      - USERS_LIST_FILE=/vpn/psw-file
    volumes:
      - ./openvpn-data:/vpn
    depends_on:
      - openvpn
    networks:
      - tailscale-net

networks:
  tailscale-net:
    driver: bridge
    ipam:
      config:
        - subnet: 100.64.0.0/24

EOF

# === Tạo script NAT ===
cat > $PROJECT_DIR/openvpn-data/ovpn_poststart.sh <<'EOF'
#!/bin/bash
iptables -t nat -A POSTROUTING -s 10.8.0.0/24 -o eth0 -j MASQUERADE
EOF
chmod +x $PROJECT_DIR/openvpn-data/ovpn_poststart.sh

# === Tạo user list cho Web UI ===
cat > $PROJECT_DIR/openvpn-data/psw-file <<EOF
alice password123
bob secretpass
EOF

# === Khởi động stack Docker ===
cd $PROJECT_DIR
docker-compose up -d

# === Đăng nhập Tailscale ===
echo ""
echo "➡️ Đăng nhập Tailscale container..."
docker exec -it tailscale tailscale up --authkey=${TAILSCALE_AUTH_KEY}

# === Khởi tạo OpenVPN (nếu lần đầu) ===
echo ""
echo "⚙️ Khởi tạo OpenVPN lần đầu..."
docker run -v "$PWD/openvpn-data:/etc/openvpn" --rm kylemanna/openvpn ovpn_genconfig -u udp://100.64.0.3
docker run -v "$PWD/openvpn-data:/etc/openvpn" --rm -it kylemanna/openvpn ovpn_initpki

# === Tạo user OpenVPN ===
echo ""
echo "👤 Tạo client 'alice'..."
docker run -v "$PWD/openvpn-data:/etc/openvpn" --rm -it kylemanna/openvpn easyrsa build-client-full alice nopass
docker run -v "$PWD/openvpn-data:/etc/openvpn" --rm kylemanna/openvpn ovpn_getclient alice > alice.ovpn

echo ""
echo "✅ Hoàn tất! File client 'alice.ovpn' đã được tạo."

echo "🌐 Truy cập Web UI tại: http://localhost:8080"
echo "🔌 VPN server Tailscale IP: 100.64.0.3:1194"
